package com.example.btvn_tuan2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etAge: EditText
    private lateinit var btnCheck: Button
    private lateinit var tvResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)  // <-- đây gọi file layout XML

        // Ánh xạ view
        etName = findViewById(R.id.etName)
        etAge = findViewById(R.id.etAge)
        btnCheck = findViewById(R.id.btnCheck)
        tvResult = findViewById(R.id.tvResult)

        // Xử lý khi nhấn nút
        btnCheck.setOnClickListener {
            val name = etName.text.toString().trim()
            val ageText = etAge.text.toString().trim()

            if (name.isEmpty() || ageText.isEmpty()) {
                tvResult.text = "Vui lòng nhập đầy đủ họ tên và tuổi!"
                return@setOnClickListener
            }

            val age = ageText.toIntOrNull()
            if (age == null || age < 0 || age > 130) {
                tvResult.text = "Tuổi không hợp lệ!"
                return@setOnClickListener
            }

            val type = when {
                age > 65 -> "Người già"
                age >= 6 -> "Người lớn"
                age >= 2 -> "Trẻ em"
                else -> "Em bé"
            }

            tvResult.text = "$name là $type"
        }
    }
}
