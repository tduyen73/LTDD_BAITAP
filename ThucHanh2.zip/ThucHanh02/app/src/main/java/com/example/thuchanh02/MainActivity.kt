package com.example.thuchanh02

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var edtInput: EditText
    private lateinit var btnCreate: Button
    private lateinit var tvError: TextView
    private lateinit var layoutContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Ánh xạ view
        edtInput = findViewById(R.id.edtInput)
        btnCreate = findViewById(R.id.btnCreate)
        tvError = findViewById(R.id.tvError)
        layoutContainer = findViewById(R.id.layoutContainer)

        btnCreate.setOnClickListener {
            val text = edtInput.text.toString().trim()  // Lấy giá trị nhập vào
            layoutContainer.removeAllViews()            // Xóa danh sách cũ

            // Nếu rỗng hoặc không phải số hợp lệ
            if (text.isEmpty() || !text.matches(Regex("^\\d+$"))) {
                tvError.visibility = View.VISIBLE
                tvError.text = "Dữ liệu bạn nhập không hợp lệ"
                return@setOnClickListener
            }

            tvError.visibility = View.GONE
            val n = text.toInt()

            if (n <= 0) {
                tvError.visibility = View.VISIBLE
                tvError.text = "Vui lòng nhập số lớn hơn 0"
                return@setOnClickListener
            }

            // Nếu hợp lệ → tạo danh sách nút
            for (i in 1..n) {
                val btn = Button(this)
                btn.text = i.toString()
                btn.setBackgroundColor(resources.getColor(android.R.color.holo_red_dark))
                btn.setTextColor(resources.getColor(android.R.color.white))
                btn.textSize = 18f
                btn.setPadding(10, 20, 10, 20)

                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                params.setMargins(0, 10, 0, 0)
                btn.layoutParams = params

                layoutContainer.addView(btn)
            }
        }
    }
}
